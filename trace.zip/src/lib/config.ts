export const APP_CONFIG = {
  builtBy: 'Your Name',
  tagline: 'Software developer & builder.',
  github: 'YOUR_GITHUB_URL',
  linkedin: 'YOUR_LINKEDIN_URL',
  x: 'YOUR_X_URL',
  portfolio: 'YOUR_PORTFOLIO_URL',
}

export const hasSupabaseEnv = Boolean(import.meta.env.VITE_SUPABASE_URL && import.meta.env.VITE_SUPABASE_ANON_KEY)
